# Requirements: Web-Based HC Signup Form (`cmd=signup`)

> Status: **Draft — for handoff to a mockup-generation session.**
> This is not yet an accepted capability; it does not belong in `docs/CONTEXT.md` until built and accepted.
> Scope of this document: enough domain + UX detail to generate a clickable HTML/CSS/JS mockup.
> It does not specify final GAS backend wiring — see §Out of Scope and §Open Questions.

---

## 1. Background

F3Go30 currently collects Hard Commit (HC) signups via a linked Google Form, which writes to
the **Responses** sheet on whichever month's tracker it is bound to (see
`docs/sheet-reference.md` §Responses, `docs/CONTEXT.md` UC-2). A PAX who wants to edit a prior
submission must use the Google Forms "edit response" link, and there is no F3Go30 affordance for
choosing *which* month's tracker a submission targets.

This feature adds a second, web-based signup path: hitting the deployed web app with
`?cmd=signup` returns an HTML page that lets a PAX identify themselves, see (and edit) their
existing signup if they already have one, and choose which month's tracker to save into.

A GAS web app dispatcher already exists per **ADR-009** (`/adr/009-web-app-dispatcher-instead-of-clasp-run.md`)
for a *different* purpose (authenticated dev/test RPC). This feature is a **separate, anonymous,
PAX-facing** entry point on the same `doGet`/`doPost` handlers in `script/WebApp.js` — it must not
reuse ADR-009's secret-validation path.

---

## 2. Actors

| Actor | Role |
|-------|------|
| PAX | Anonymous web visitor identifying by F3 Name + Email |
| Site Q | Not directly involved in this flow; benefits from reduced manual edit requests |

---

## 3. Deployment Target

The web app is deployed against the **Template** script project (`templateScriptId` in
`local.settings.json`) — the same project used today for `TEST_APP`/`clasp deploy
--deploymentId`. This keeps one stable `/exec` URL forever; the handler resolves "current month"
and "next month" tracker spreadsheets dynamically at request time (see §6.3) rather than being
redeployed monthly the way the HC Google Form is.

---

## 4. Entry Point

```
GET  https://script.google.com/macros/s/<DEPLOYMENT_ID>/exec?cmd=signup
```

Returns an HTML page (GAS `HtmlService`) implementing the full multi-step flow client-side.
Step transitions happen in JavaScript (no full page reloads) until the final save, which is a
`doPost` call.

**Technical constraint:** GAS `HtmlService` serves static files with no build step. The mockup
must be plain HTML + CSS + vanilla JS (or a single-file framework loaded from a CDN `<script>`
tag) — no bundler, no npm install step, nothing that assumes a Node toolchain at serve time.

---

## 5. Flow

### Step 1 — Intro

Static welcome screen. Content:
- Go30 branding (see §7 Visual Style)
- One-paragraph explanation: "Sign up or update your Go30 Hard Commit"
- Single **Get Started** button → advances to Step 2

### Step 2 — Identify

Two fields, both required:
- **F3 Name** (text)
- **Email** (email, validated client-side)

Single **Continue** button. On submit, calls the backend to look up a match (see §6.1) and
advances to Step 3 with either the loaded data or a blank form.

No error message should distinguish "name found, email didn't match" from "no record at all" —
see §6.1, this is a deliberate anti-enumeration measure. Show a neutral "Welcome! Let's get your
info" for both the blank and loaded cases (loaded case additionally shows "We found your previous
signup — review and update below").

### Step 3 — Signup Info

Form fields, sourced from the Responses sheet field set (`RESPONSE_COLUMN_MAP` in
`script/response_utils.js`) — **F3 Name and Email are carried over from Step 2, read-only on this
step** (changing identity fields belongs in a separate edit, not this flow):

| Field | Type | Source key | Notes |
|-------|------|-----------|-------|
| F3 Name | text, read-only | `F3_NAME` | from Step 2 |
| Email | email, read-only | `EMAIL` | from Step 2 |
| Team type (AO-based vs goal-based) | radio/select | `TEAM_TYPE` | optional column today — keep optional |
| Team | select or text | `TEAM` | pick from known teams if list is available, else free text |
| Other team name | text | `OTHER_TEAM` | shown conditionally when Team = "Other" (mirrors current form logic — see `signupReuse.js` `OTHER_TEAM` handling) |
| WHO do you ultimately want to become? | textarea | `WHO` | |
| WHAT is your Go30 Challenge? | textarea | `WHAT` | |
| HOW are you going to be successful this month? | textarea | `HOW` | |
| Cell Phone Number | tel | `PHONE` | |
| Nag email opt-in | checkbox | `NAG_EMAIL` | reminder-email consent, per UC-6 |

If Step 2 found a match, every field above is pre-filled from the matched Responses row and is
editable. If no match, all fields start blank.

**Out of scope for this form:** `PARTICIPATION` ("Are you currently participating in Go30?") —
that field exists to drive the Google Form's "reuse last month's goals" branch
(`signupReuse.js`), which this flow replaces functionally (identify-then-edit achieves the same
goal more directly). Do not surface it as a question.

### Step 4 — Choose Target Month & Save

Before showing this step, the backend has already resolved which tracker months are available to
save into (§6.3):

- **Current month** — always available (it's the tracker context the signup is happening in)
- **Next month** — only shown if next month's tracker already exists

Render as a single choice (radio buttons or two buttons), each labeled with the actual month name
and year — reuse the `"Month YYYY"` format already produced by `formatRegistrationMonth_()` in
`script/addResponseOnSubmit.js` (e.g. "June 2026"), not generic words like "current"/"next":

```
○ Save for June 2026
○ Save for July 2026   (only rendered if next month's tracker exists)
```

A single **Save Signup** button submits. On success, show a confirmation screen with the saved
month name and a link back to that month's tracker (mirrors the existing registration
confirmation email content in `signupReuse.js` `sendRegistrationConfirmationEmail_`).

---

## 6. Business Rules

### 6.1 Matching rule (security-relevant)

Match requires **F3 Name AND Email to both match** an existing Responses row, case-insensitive.
This is a deliberate access-control check, not just dedup convenience: F3 Name is publicly visible
on the Tracker/leaderboard sheets, but Email is not displayed anywhere a PAX could see another
participant's address. Requiring both prevents someone who only knows a public F3 Name from
viewing or editing that person's private signup data (phone number, goals, etc).

- F3 Name matches but Email doesn't (or vice versa) → **treat as no match**, render the blank-form
  state. Do not reveal that the name exists.
- This intentionally differs from the Tracker's own dedup key, which is F3 Name only (ADR-008) —
  that's an internal anti-duplicate-row rule with different stakes than this PAX-facing lookup.

### 6.2 Save behavior — new vs. edit

- If Step 2 produced a match **and** the PAX chooses to save for the **same month** the match was
  found in: update that Responses row in place (no duplicate).
- If the PAX saves for a **different month** than where the match was found (e.g. matched in
  June's tracker, saving for July): write a new row into July's Responses sheet — semantically
  this is the same "carry goals forward" operation `signupReuse.js`
  (`maybeReuseLastMonthsGoals_`) already performs, just initiated by the PAX directly instead of
  via the Google Form's reuse checkbox.
- If no match was found: always a new row, in whichever month's Responses sheet was chosen.
- Whatever path is taken, the chosen target tracker's **Tracker** sheet must end up with a row for
  that F3 Name too (mirroring `handleFormSubmit_` in `script/addResponseOnSubmit.js`) — saving via
  this form must produce the same downstream state as a Google Form submission would.

### 6.3 Resolving "current month" and "next month" tracker

Because the web app is deployed on the Template (§3), it has no single fixed "current tracker."
At request time, resolve both targets from the Template's **Links** sheet (the append-only record
populated by every tracker creation — see `docs/CONTEXT.md` Core Capabilities, and
`CreateNewTracker.js`'s links-append logic):

- **Current month** = the Links row whose start date is the most recent one not in the future.
- **Next month** = a Links row whose start date is exactly one calendar month after the current
  month's start date, if one exists (it will, between the 20th auto-generate run and end of
  month — see UC-4). If absent, only "current month" is offered in Step 4.

This logic does not need to be implemented for the mockup — the mockup should accept these two
month names (and their save-target identifiers) as mock/stubbed data, so it can be wired to the
real Links-sheet lookup later without changing the UI.

---

## 7. Visual Style

No existing web UI to match (Apps Script editor and Sheets are the only current surfaces), but
reuse the palette already established in F3Go30's HTML email templates
(`script/OnboardingEmailTemplate.html`, `ReminderEmailTemplate.html`,
`ResponseSettingsEmailTemplate.html`, `SignupReuseEmailTemplate.html`) so the signup form feels
visually consistent with the emails a PAX already receives:

| Use | Color |
|-----|-------|
| Header background | `#2f5d50` (deep green) |
| Header/body text on dark | `#f8f4ea` (cream) |
| Page/card background | `#f4f1ea` (light cream) |
| Card surface | `#fffdf8` |
| Card border | `#d8cfbf` (tan) |
| Link/action accent | `#0b5c86` (blue) |
| Callout/highlight border | `#b8860b` (gold) |
| Body font | Arial, sans-serif |

Must be mobile-friendly — PAX will most often open this from a phone via a text or Slack link.

---

## 8. Out of Scope

- Real GAS backend wiring (`doGet`/`doPost` dispatch logic, actual Sheet reads/writes, Links
  sheet resolution) — this document specifies the UI/UX and data contract only; backend
  implementation is a separate, later task in this repo.
- Replacing or deprecating the existing Google Form HC signup — both paths coexist.
- The `PARTICIPATION` reuse-checkbox flow from the Google Form (superseded by the identify step,
  see §5 Step 3).
- Authentication beyond the F3-Name+Email match check — there is no login; this is the same trust
  model as the existing anonymous Google Form.
- ADR-009's secret-based dispatcher path — unrelated, must not be touched by this feature's
  routing.

---

## 9. Deliverable Expected From the Mockup Session

A clickable HTML/CSS/JS prototype (single `.html` file or a small set of files with inlined
CSS/JS, consistent with GAS `HtmlService` constraints from §4) covering all four steps in §5, using
mock/stubbed data for:
- A "found match" scenario (Step 2 → pre-filled Step 3)
- A "no match" scenario (Step 2 → blank Step 3)
- Both "next month available" and "next month not yet available" variants of Step 4

No real network calls are required in the mockup — stub the identify lookup and the final save
with local JS functions returning canned data, structured so the real `doPost` payload shape can
be slotted in later without restructuring the UI.

---

## 10. Open Questions (not blocking the mockup, but blocking backend implementation)

- Exact `doPost` request/response JSON shape for `cmd=signup` (identify lookup) and the save
  action — to be designed alongside the real backend work, informed by the mockup's data needs.
- Whether "Team" should be a dropdown of currently-known teams (queried live) or stay free text
  as today.
- Whether saving for a future month before that month's tracker has its own Tracker-sheet row
  population logic needs any additional safeguard beyond mirroring `handleFormSubmit_`.
